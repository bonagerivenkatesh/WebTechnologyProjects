var $scope;
var app = angular.module('miniapp', []);
var $count=0;
var $winner=null;
var $arr=['O','O'];
function tic($scope)
{

    $scope.om1=null;
    $scope.om2=null;
    $scope.om3=null;
    $scope.om4=null;
    $scope.om5=null;
    $scope.om6=null;
    $scope.om7=null;
    $scope.om8=null;
    $scope.om9=null;

        $scope.play1 = function(obj) 
        {
            $count++;
            $count=$count%2;
            $scope.om1=$arr[$count];
            setTimeout(comp(),3000);
            setTimeout(chec(),3000);
            setTimeout(finish(),3000);
        
        }

       $scope.play2 = function(obj)
       {
            $count++;
            $count=$count%2;
            $scope.om2=$arr[$count];
            setTimeout(comp(),3000);
            setTimeout(chec(),3000);
            setTimeout(finish(),3000);
      }

      $scope.play3 = function(obj)
      {
            $count++;
            $count=$count%2;
            $scope.om3=$arr[$count];
            setTimeout(comp(),3000);
            setTimeout(chec(),3000);
            setTimeout(finish(),3000);
      }

    $scope.play4 = function(obj) {

        $count++;
        $count=$count%2;
        $scope.om4=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);
        
    }

    $scope.play5 = function(obj) {

        $count++;
        $count=$count%2;
        $scope.om5=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);
        
    }

    $scope.play6 = function(obj) {

        $count++;
        $count=$count%2;
        $scope.om6=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);
        
    }

    $scope.play7 = function(obj) {

        $count++;
        $count=$count%2;
        $scope.om7=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);
        
    }

    $scope.play8 = function(obj) {
        $count++;
        $count=$count%2;
        $scope.om8=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);
        

    }

    $scope.play9 = function(obj) {

        $count++;
        $count=$count%2;
        $scope.om9=$arr[$count];
        setTimeout(comp(),3000);
        setTimeout(chec(),3000);
        setTimeout(finish(),3000);

    }


    function comp()
    {
        
        var flag=0;
        
        if($scope.om1=='X')
         {
            if($scope.om2=='X' && $scope.om3==null)
                {
                    $scope.om3='X';
                   flag=1;
                }
             else if($scope.om3=='X' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om4=='X' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om7=='X' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
        
        if($scope.om2=='X' && flag==0)
         {
            if($scope.om1=='X' && $scope.om3==null)
                {
                    $scope.om3='X';
                   flag=1;
                }
             else if($scope.om3=='X' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om8=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om3=='X'  && flag==0)
         {
            if($scope.om2=='X' && $scope.om1==null)
                {
                    $scope.om1='X';
                   flag=1;
                }
             else if($scope.om1=='X' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om6=='X' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='X' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om7=='X' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
         }
          if($scope.om4=='X'  && flag==0)
         {
            if($scope.om1=='X' && $scope.om7==null)
                {
                    $scope.om7='X';
                   flag=1;
                }
             else if($scope.om7=='X' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om6=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om5=='X'  && flag==0)
         {
            if($scope.om4=='X' && $scope.om6==null)
                {
                    $scope.om6='X';
                   flag=1;
                }
             else if($scope.om6=='X' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om2=='X' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om8=='X' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om1=='X' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='X' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om3=='X' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
              else if($scope.om7=='X' && $scope.om3==null)
                  {
                      $scope.om3='X';
                      flag=1;
                  }
         }
          if($scope.om6=='X'  && flag==0)
         {
            if($scope.om2=='X' && $scope.om4==null)
                {
                    $scope.om4='X';
                   flag=1;
                }
             else if($scope.om4=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
             else if($scope.om3=='X' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='X' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
         }
          if($scope.om7=='X'  && flag==0)
         {
            if($scope.om8=='X' && $scope.om9==null)
                {
                    $scope.om9='X';
                   flag=1;
                }
             else if($scope.om9=='X' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om1=='X' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om4=='X' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
             else if($scope.om3=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om8=='X'  && flag==0)
         {
            if($scope.om7=='X' && $scope.om9==null)
                {
                    $scope.om9='X';
                   flag=1;
                }
             else if($scope.om9=='X' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om4=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             }
          if($scope.om9=='X'  && flag==0)
         {
            if($scope.om7=='X' && $scope.om8==null)
                {
                    $scope.om8='X';
                   flag=1;
                }
             else if($scope.om8=='X' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om3=='X' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om6=='X' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
             else if($scope.om5=='X' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om1=='X' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om1=='O'  && flag==0)
         {
            if($scope.om2=='O' && $scope.om3==null)
                {
                    $scope.om3='X';
                   flag=1;
                }
             else if($scope.om3=='O' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om4=='O' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om7=='O' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
         if($scope.om2=='O'  && flag==0)
         {
            if($scope.om1=='O' && $scope.om3==null)
                {
                    $scope.om3='X';
                   flag=1;
                }
             else if($scope.om3=='O' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om8=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om3=='O'  && flag==0)
         {
            if($scope.om2=='O' && $scope.om1==null)
                {
                    $scope.om1='X';
                   flag=1;
                }
             else if($scope.om1=='O' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om6=='O' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='O' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om7=='O' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
         }
          if($scope.om4=='O'  && flag==0)
         {
            if($scope.om1=='O' && $scope.om7==null)
                {
                    $scope.om7='X';
                   flag=1;
                }
             else if($scope.om7=='O' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om6=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om5=='O'  && flag==0)
         {
            if($scope.om4=='O' && $scope.om6==null)
                {
                    $scope.om6='X';
                   flag=1;
                }
             else if($scope.om6=='O' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om2=='O' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om8=='O' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             else if($scope.om1=='O' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='O' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om3=='O' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
              else if($scope.om7=='O' && $scope.om3==null)
                  {
                      $scope.om3='X';
                      flag=1;
                  }
         }
          if($scope.om6=='O'  && flag==0)
         {
            if($scope.om2=='O' && $scope.om4==null)
                {
                    $scope.om4='X';
                   flag=1;
                }
             else if($scope.om4=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
             else if($scope.om3=='O' && $scope.om9==null)
                 {
                     $scope.om9='X';
                     flag=1;
                 }
             else if($scope.om9=='O' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
         }
          if($scope.om7=='O'  && flag==0)
         {
            if($scope.om8=='O' && $scope.om9==null)
                {
                    $scope.om9='X';
                   flag=1;
                }
             else if($scope.om9=='O' && $scope.om8==null)
                 {
                     $scope.om8='X';
                     flag=1;
                 }
             else if($scope.om1=='O' && $scope.om4==null)
                 {
                     $scope.om4='X';
                     flag=1;
                 }
             else if($scope.om4=='O' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
             else if($scope.om3=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om8=='O'  && flag==0)
         {
            if($scope.om7=='O' && $scope.om9==null)
                {
                    $scope.om9='X';
                   flag=1;
                }
             else if($scope.om9=='O' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om4=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om2==null)
                 {
                     $scope.om2='X';
                     flag=1;
                 }
             }
          if($scope.om9=='O'  && flag==0)
         {
            if($scope.om7=='O' && $scope.om8==null)
                {
                    $scope.om8='X';
                   flag=1;
                }
             else if($scope.om8=='O' && $scope.om7==null)
                 {
                     $scope.om7='X';
                     flag=1;
                 }
             else if($scope.om3=='O' && $scope.om6==null)
                 {
                     $scope.om6='X';
                     flag=1;
                 }
             else if($scope.om6=='O' && $scope.om3==null)
                 {
                     $scope.om3='X';
                     flag=1;
                 }
             else if($scope.om5=='O' && $scope.om1==null)
                 {
                     $scope.om1='X';
                     flag=1;
                 }
             else if($scope.om1=='O' && $scope.om5==null)
                 {
                     $scope.om5='X';
                     flag=1;
                 }
         }
          if($scope.om5==null  && flag==0)
           {
               $scope.om5='X';
               flag=1;
           }
          if($scope.om1==null  && flag==0)
           {
               $scope.om1='X';
               flag=1;
           }

          if($scope.om2==null  && flag==0)
           {
               $scope.om2='X';
               flag=1;
           }
          if($scope.om3==null  && flag==0)
           {
               $scope.om3='X';
               flag=1;
           }
          if($scope.om4==null  && flag==0)
           {
               $scope.om4='X';
               flag=1;
           }
          if($scope.om6==null  && flag==0)
           {
               $scope.om6='X';
               flag=1;
           }
          if($scope.om7==null  && flag==0)
           {
               $scope.om7='X';
               flag=1;
           }
          if($scope.om8==null  && flag==0)
           {
               $scope.om8='X';
               flag=1;
           }
          if($scope.om9==null  && flag==0)
           {
               $scope.om9='X';
               flag=1;
           }
  
    }

    function chec()
    {

        if($winner==null)
        {
        if($scope.om1==$scope.om2 && $scope.om2==$scope.om3 && $scope.om1.length>0)
        {
            alert($scope.om1+" won");
            $winner=$scope.om3;
        }

        else if($scope.om4==$scope.om5 && $scope.om5==$scope.om6  && $scope.om4.length>0)
        {
            alert($scope.om4+" won");
            $winner=$scope.om4;
        }
        else if($scope.om7==$scope.om8 && $scope.om8==$scope.om9  && $scope.om7.length>0)
                   {
            alert($scope.om7+" won");
            $winner=$scope.om7;
        }
        else if($scope.om1==$scope.om4 && $scope.om4==$scope.om7  && $scope.om1.length>0)
                    {
            alert($scope.om1+" won");
            $winner=$scope.om1;
        }
        else if($scope.om2==$scope.om5 && $scope.om5==$scope.om8  && $scope.om2.length>0)
                 {
            alert($scope.om2+" won");
            $winner=$scope.om2;
        }
        else if($scope.om3==$scope.om6 && $scope.om6==$scope.om9  && $scope.om3.length>0)
                    {
            alert($scope.om3+" won");
            $winner=$scope.om3;
        }
        else if($scope.om1==$scope.om5 && $scope.om5==$scope.om9  && $scope.om1.length>0)
                   {
            alert($scope.om1+" won");
            $winner=$scope.om1;
        }
        else if($scope.om3==$scope.om5 && $scope.om5==$scope.om7  && $scope.om3.length>0)
                    {
            alert($scope.om3+" won");
            $winner=$scope.om3;
        }
            else if($scope.om1.length>0 && $scope.om2.length>0 && $scope.om3.length>0 && $scope.om4.length>0 && $scope.om5.length>0 && $scope.om6.length>0 && $scope.om7.length>0 && $scope.om8.length>0 && $scope.om9.length>0)
            {
                    alert("Match Tied");
            }

    }
    else
        alert($winner+" has won the match long back");

        return;


    }


    function finish()
    {
        if($winner!=null)
     {

        $scope.ven=$winner+" won the match";
        if($scope.om1==null)
            $scope.om1="---";
        if($scope.om2==null)
            $scope.om2="---";
        if($scope.om3==null)
            $scope.om3="---";
        if($scope.om4==null)
            $scope.om4="---";
        if($scope.om5==null)
            $scope.om5="---";
        if($scope.om6==null)
            $scope.om6="---";
        if($scope.om7==null)
            $scope.om7="---";
        if($scope.om8==null)
            $scope.om8="---";
        if($scope.om9==null)
            $scope.om9="---";
     }

     var fill=0;
         if($scope.om1.length==1)
            fill++;
        if($scope.om2.length==1)
            fill++;
        if($scope.om3.length==1)
            fill++;
        if($scope.om4.length==1)
            fill++;
        if($scope.om5.length==1)
            fill++;
        if($scope.om6.length==1)
            fill++;
        if($scope.om7.length==1)
            fill++;
        if($scope.om8.length==1)
            fill++;
        if($scope.om9.length==1)
            fill++;

      if(fill==9)
          $scope.ven="Match Tied";
    }

   $scope.dis1 = function(o)
    {

        if($scope.om1.length>0)
            return true;
        else
            return false;
    }

	$scope.dis2 = function(o)
    {

        if($scope.om2.length>0)
            return true;
        else
            return false;
    }


	$scope.dis3 = function(o)
    {

        if($scope.om3.length>0)
            return true;
        else
            return false;
    }


	$scope.dis4 = function(o)
    {

        if($scope.om4.length>0)
            return true;
        else
            return false;
    }

	$scope.dis5 = function(o)
    {

        if($scope.om5.length>0)
            return true;
        else
            return false;
    }


	$scope.dis6 = function(o)
    {

        if($scope.om6.length>0)
            return true;
        else
            return false;
    }

	$scope.dis7 = function(o)
    {

        if($scope.om7.length>0)
            return true;
        else
            return false;
    }


    $scope.dis8 = function(o)
    {

        if($scope.om8.length>0)
            return true;
        else
            return false;
    }

	$scope.dis9 = function(o)
    {

        if($scope.om9.length>0)
            return true;
        else
            return false;
    }




};
